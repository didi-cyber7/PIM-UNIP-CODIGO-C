O desenvolvimento do código-fonte foi realizado utilizando a linguagem de programação C, seguindo os princípios da programação estruturada e buscando construir uma aplicação organizada, funcional e de fácil manutenção. Durante o processo, dividimos o sistema em módulos independentes, de modo que cada arquivo fosse responsável por um conjunto específico de operações, facilitando a implementação, a manutenção e a identificação de possíveis erros. Inicialmente, organizamos a estrutura do projeto, separando os arquivos de cabeçalho, responsáveis pelas declarações de estruturas e funções, dos arquivos de implementação, nos quais foram desenvolvidas as regras de negócio e as operações do sistema. Essa divisão permitiu estabelecer uma comunicação entre os diferentes módulos sem concentrar todas as funcionalidades em um único arquivo.



Para representar as informações utilizadas pelo sistema, implementamos estruturas (`struct`), responsáveis por agrupar dados relacionados, como os cadastros das camareiras, os registros de atendimento e os indicadores de produtividade. Também utilizamos vetores para armazenar e manipular conjuntos de informações, permitindo percorrer registros, realizar comparações e atualizar dados durante a execução. Uma das principais funcionalidades desenvolvidas foi o processo de distribuição diária das unidades habitacionais (UHs). Para implementar essa lógica, desenvolvemos inicialmente uma rotina responsável por identificar quais camareiras estavam presentes. Em seguida, o sistema realiza a atribuição das UHs fixas às profissionais disponíveis, preservando suas responsabilidades originais. Posteriormente, as unidades pertencentes às camareiras ausentes são redistribuídas individualmente, priorizando aquela que apresenta a menor quantidade de UHs atribuídas naquele momento. Nesse processo, implementamos também um critério de desempate baseado no menor identificador da camareira, garantindo que a distribuição seja determinística e siga uma regra consistente. Além disso, desenvolvemos verificações para impedir que o processo continue quando não houver nenhuma profissional presente, evitando situações inválidas durante a execução. Ao final, o sistema apresenta o mapa de distribuição, identificando as unidades titulares e aquelas recebidas por substituição.



Outra funcionalidade central foi o cálculo dos indicadores de produtividade. Para desenvolvê-la, implementamos uma rotina que percorre os registros de atendimento e agrupa as informações de acordo com a camareira responsável. A partir desses registros, o sistema contabiliza o total de UHs atendidas, a quantidade de atendimentos titulares, as substituições realizadas e o tempo total empregado. Com esses dados, desenvolvemos uma função específica para calcular o tempo médio de atendimento por UH, utilizando a divisão entre o tempo total registrado e a quantidade de unidades atendidas. Também implementamos uma rotina de ordenação utilizando o método Bubble Sort, organizando os resultados em ordem crescente de tempo médio. Dessa maneira, o relatório permite visualizar as profissionais com menores médias de atendimento antes das demais, conforme a regra estabelecida para essa funcionalidade.



Para garantir a persistência das informações, utilizamos arquivos CSV e arquivos de texto (TXT). Essa abordagem permite armazenar registros e recuperar dados posteriormente, sem depender de um banco de dados externo para a execução do sistema em linguagem C. Também desenvolvemos rotinas específicas de leitura e gravação, responsáveis por interpretar os dados existentes, atualizar informações e gerar relatórios. Na distribuição diária, por exemplo, o sistema registra as atribuições realizadas, permitindo consultar posteriormente a classificação de cada atendimento. Durante a construção, procuramos separar as operações em funções específicas, evitando a repetição desnecessária de código e tornando cada etapa mais compreensível. Também implementamos estruturas condicionais e laços de repetição para controlar o fluxo de execução, validar situações e percorrer os registros armazenados. Em pontos importantes, incluímos verificações para tratar dados inválidos, limites de armazenamento e situações em que determinadas operações não podem ser executadas.



Por fim, realizamos uma revisão da organização do código e uma compilação utilizando o padrão C11, com opções de compilação voltadas à identificação de avisos e possíveis problemas. Essa etapa foi importante para verificar a integridade estrutural do projeto e corrigir eventuais inconsistências de compilação. O projeto também possui arquivos de testes automatizados em PowerShell, destinados à verificação de diferentes regras e fluxos do sistema, embora sua execução não tenha sido considerada nesta etapa de avaliação. Dessa forma, conduzimos a construção do código com foco na aplicação prática dos conceitos de programação estruturada, utilizando estruturas, vetores, funções, condicionais, laços de repetição e manipulação de arquivos. O resultado é um sistema modular, desenvolvido para atender às regras estabelecidas para a distribuição de UHs e o acompanhamento da produtividade das camareiras, mantendo uma organização que permite futuras correções e ampliações.



**Referências bibliográficas e materiais de apoio:**



**- ADREGO, Antônio. Estruturas de Dados e Algoritmos em C. Publicado em 01/02/2014 pela Editora FCA.**

**- GUANABARA, Gustavo. Cursos em vídeo disponibilizados na plataforma YouTube: Linguagem C e Curso de Algoritmos e Lógica de Programação.**

